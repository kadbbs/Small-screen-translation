#ifndef SER_SERIAL_H
#define SER_SERIAL_H



void set_arg(int fd);

#endif // !DEBUG
